function redirectToReservationDetails(id){
    return location.href="/detail-reservation?reservationID=" + id;
}
