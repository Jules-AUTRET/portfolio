# Lance les conteneurs Docker et construit les images si nécessaire
docker-compose up -d --build

# Affiche un message pour indiquer que les conteneurs sont opérationnels
Write-Host "Docker containers are up and running"

# Ceci est un script Powershell
