docker-compose up -d --build
echo "Docker containers are up and running"